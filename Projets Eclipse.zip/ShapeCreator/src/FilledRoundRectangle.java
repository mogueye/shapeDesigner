import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import model.shapes.Shape;
import view.ShapeType;


public class FilledRoundRectangle extends ShapeType {

	public FilledRoundRectangle(){
		super();
	}

	@Override
	public boolean contains(Shape shape, int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "FilledRoundRectangle";
	}

	public void paintShape(Graphics g, Shape shape){
		if(shape.points.size() >= 2){
			Point a = shape.points.get(0);
			Point b = shape.points.get(1);
			
			g.setColor(Color.LIGHT_GRAY);
			g.fillRoundRect(a.x, a.y, Math.abs(a.x-b.x), Math.abs(a.y-b.y), 10, 10);
			g.setColor(Color.BLACK);
		}
	}
}
