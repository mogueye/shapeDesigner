import java.awt.Graphics;
import java.awt.Point;

import model.shapes.Shape;
import view.ShapeType;


public class Arc extends ShapeType {

	public Arc(){
		super();
	}

	@Override
	public boolean contains(Shape shape, int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Arc";
	}

	public void paintShape(Graphics g, Shape shape){
		if(shape.points.size() >= 2){
			Point a = shape.points.get(0);
			Point b = shape.points.get(1);
			
			g.drawArc(a.x, a.y, Math.abs(a.x-b.x), Math.abs(a.y-b.y), 45, 90);
		}
	}
}
