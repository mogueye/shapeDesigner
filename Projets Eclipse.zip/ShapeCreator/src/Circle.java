import java.awt.Graphics;
import java.awt.Point;

import model.shapes.Shape;
import view.ShapeType;


public class Circle extends ShapeType {

	public Circle(){
		super();
	}

	@Override
	public boolean contains(Shape shape, int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Circle";
	}
	
	public String getDescription(){
		return "Dessine un cercle";
	}

	public void paintShape(Graphics g, Shape shape){
		if(shape.points.size() >= 2){
			Point a = shape.points.get(0);
			Point b = shape.points.get(1);
			
			g.drawOval(a.x, a.y, Math.abs(a.x-b.x), Math.abs(a.y-b.y));
		}
	}
}
