package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;

/**
 * Class which inherits javax.swing.JRadioButton.
 * @version 1.0
 * @date Mar. 2017
 * @details Its allows users to select ShapeType objects for their drawing actions.
 * @see ShapeType
 */
public class ShapeTypeRadioButton extends JRadioButton implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected ShapeType shapeType = null; /**< a ShapeType object to which the ShapeTypeRadioButton object is linked */
	
	public ShapeTypeRadioButton(ShapeType shapeType, ButtonGroup group){
		super(shapeType.getName());
		this.shapeType = shapeType;
		this.setToolTipText(shapeType.getDescription());
		this.setActionCommand(shapeType.getName());
		this.addActionListener(this);
		group.add(this);
	}
	
	@Override
	/**
	 * When the ShapeTypeRadioButton is checked, its set its linked ShapeType object to selected state
	 */
	public void actionPerformed(ActionEvent arg0) {
		shapeType.setSelected();
	}
}
