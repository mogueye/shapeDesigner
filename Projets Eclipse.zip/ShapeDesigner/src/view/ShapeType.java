package view;

import java.awt.Graphics;
import java.awt.Point;

import model.shapes.Shape;

/**
 * Abstract class which define the interface of all shape types
 * @version 1.0
 * @date Mar. 2017
 * @see Shape
 */
public abstract class ShapeType {
	protected static ShapeType SELECTED_SHAPE = null; /**< a static attribut which determines the selected shape type */
	
	/**
	 * Returns the user selected shape type
	 * @return a ShapeType object
	 */
	public static ShapeType getSelectedShape(){
		return ShapeType.SELECTED_SHAPE;
	}
	
	/**
	 * Allows to knows if the user has selected a shape type
	 * @return a boolean value
	 */
	public static boolean isSelectedShape(){
		return ShapeType.SELECTED_SHAPE != null;
	}
		
	public ShapeType(){}
	
	/**
	 * When called on a ShapeType object, the latter becomes the current shape type to user in response of the user action.
	 */
	public void setSelected(){
		ShapeType.SELECTED_SHAPE = this;
	}
	
	/**
	 * Verifies if a given shape with this shape type contains a point or not
	 * @param shape a Shape object
	 * @param p a java.awt.Point object
	 * @return a boolean value
	 */
	public boolean contains(Shape shape, Point p){
		return contains(shape, p.x, p.y);
	}
	
	/**
	 * Verifies if a given shape with this shape type contains a point or not
	 * @param shape a Shape object
	 * @param x the abscissa of the point
	 * @param y the ordinate of the point
	 * @return a boolean value
	 */
	public abstract boolean contains(Shape shape, int x, int y);

	/**
	 * Must return the name of the shape type (e.g., Line, Rectangle, Circle and so on)
	 * @return a String object
	 */
	public abstract String getName();
	
	/**
	 * Must return a short description of the shape type
	 * @return a String object
	 */
	public String getDescription(){
		return null;
	}
	
	/**
	 * Ask the ShapeType object to paint a shape
	 * @param g a java.awt.Graphics object
	 * @param shape a Shape object
	 */
	public abstract void paintShape(Graphics g, Shape shape);
}
