package view;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.UIManager;

import control.UserActionControler;

/**
 * @class MainFrame
 * @author Modou Gueye
 * @version 1.0
 * @date Mar. 2017
 * @brief Main class of the application.
 * @details It defines the composition of the application UI.
 * @see OptionsPanel
 * @see DrawingPanel
 * @see UserActionControler
 */
public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Prepares application starting and defines the user interface
	 */
	public MainFrame(){
		super();
		this.setBounds(50, 50, 700, 500);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		this.setLayout(new BorderLayout());
		
		this.add(new OptionsPanel(), BorderLayout.NORTH);
		
		DrawingPanel drawingPanel = new DrawingPanel();
		this.add(drawingPanel, BorderLayout.CENTER);
		
		UserActionControler userActionControler = new UserActionControler(drawingPanel);
		drawingPanel.setUserActionControler(userActionControler);
		
		this.setResizable(true);
		this.setVisible(true);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{ 
	    	UIManager.setLookAndFeel(
	    	UIManager.getSystemLookAndFeelClassName());
	    } 
	    catch(Exception e){}
	    new MainFrame();
	}

}
