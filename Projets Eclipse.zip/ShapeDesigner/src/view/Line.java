package view;

import java.awt.Graphics;
import java.awt.Point;

import model.shapes.Shape;

public class Line extends ShapeType {

	public Line(){
		super();
	}

	@Override
	public boolean contains(Shape shape, int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Line";
	}

	public String getDescription(){
		return "Dessine une ligne droite";
	}
	
	public void paintShape(Graphics g, Shape shape){
		if(shape.points.size() >= 2){
			Point a = shape.points.get(0);
			Point b = shape.points.get(1);
			
			g.drawLine(a.x, a.y, b.x, b.y);
		}
	}
}
