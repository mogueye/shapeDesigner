package view;

import java.awt.Graphics;
import java.awt.Point;

import model.shapes.Shape;

public class Rectangle extends ShapeType {

	public Rectangle(){
		super();
	}

	@Override
	public boolean contains(Shape shape, int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Rectangle";
	}

	public void paintShape(Graphics g, Shape shape){
		if(shape.points.size() >= 2){
			Point a = shape.points.get(0);
			Point b = shape.points.get(1);
			
			g.drawRect(a.x, a.y, Math.abs(a.x-b.x), Math.abs(a.y-b.y));
		}
	}
}
