package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Vector;

import javax.swing.JPanel;

import model.shapes.Shape;

import control.UserActionControler;

/**
 * Class which inherits javax.swing.JPanel.
 * @version 1.0
 * @date Mar. 2017
 * @details It is the drawing board where users can draw several shape types. Its painting method was redefined.
 * @see Shape
 * @see UserActionControler
 */
public class DrawingPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected UserActionControler userActionControler; /**< a UserActionControler object which controls the user actions */
	Vector<Shape> shapes;            				   /**< list of user drawn shapes */

	/**
	 * Initializes the list of shapes
	 */
	public DrawingPanel(){
		super();
		this.setMinimumSize(new Dimension(50, 400));
		this.setSize(new Dimension(50, 400));

		this.setBackground(Color.WHITE);
		this.setForeground(Color.BLACK);

		this.shapes = new Vector<Shape>();
	}

	/**
	 * A surdefined constructor
	 */
	public DrawingPanel(UserActionControler userActionControler){
		this();
		this.setUserActionControler(userActionControler);
	}

	/**
	 * Define the panel's listener of mouse events. A UserActionControler object is expected in entry.
	 * @param userActionControler a UserActionControler object
	 */
	public void setUserActionControler(UserActionControler userActionControler){
		this.userActionControler = userActionControler;
		if(userActionControler != null){
			this.addMouseListener(userActionControler);
			this.addMouseMotionListener(userActionControler);
		}
	}

	/**
	 * Add a new entry into the list of shapes and repaint all the drawing board
	 * @param shape a Shape object
	 */
	public void addShape(Shape shape){
		if(shape != null){
			this.shapes.add(shape);
			this.repaint();
		}
	}

	/**
	 * Redefinition of the painting method in order to draw the list of user-drawn shapes.
	 */
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		ShapeType shapeType;
		for(Shape shape : shapes){
			shapeType = shape.getShapeType();
			
			if(shapeType != null)
				shapeType.paintShape(g, shape);
		}
	}
}
