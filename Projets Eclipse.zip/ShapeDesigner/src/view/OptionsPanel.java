package view;

import java.awt.Dimension;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLDecoder;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * @class OptionsPanel
 * @author Modou Gueye
 * @version 1.0
 * @date Mar. 2017
 * @brief 
 * @details It allows the dynamic loading of drawable shapes as plug-ins from the directory "./plugins"
 * @see ShapeType
 * @see ShapeTypeRadioButton
 * @see MainFrame
 */
public class OptionsPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected Vector<ShapeType> shapeTypes = null; /**< list of all defined shape types */

	/**
	 * Constructor of the class OptionsPanel.
	 * It loads defined and additional shape types from the directory "./plugins"
	 */
	public OptionsPanel(){
		super();
		this.setMinimumSize(new Dimension(150, 400));
		this.setSize(new Dimension(150, 400));

		shapeTypes = new Vector<ShapeType>(); // Initialization of the container of ShapeType objects

		this.loadOptions(); // Loading defined shape types from the directory "./plugins"
	}

	/**
	 * It does to tasks:
	 * 1) Instantiation of the following defined shape types : Line and Rectangle
	 * 2) Dynamic laoding of additional shape types from from the directory "./plugins"
	 * Each ShapeType object is represented by a JRadioButton in the application UI. 
	 * The check on a radio button allows user to select the current shape type to use.
	 */
	protected void loadOptions(){
		ButtonGroup group = new ButtonGroup(); // Cr�ation d'un groupe de boutons pour regrouper les boutons radio
		ShapeType shapeType = null;

		// Cr�ation du type de forme correspondant aux dessins de ligne
		shapeType = new Line();
		shapeTypes.add(shapeType);
		this.add(this.createButton(shapeType, group));

		// Cr�ation du type de forme correspondant aux dessins de rectangle vide
		shapeType = new Rectangle();
		shapeTypes.add(shapeType);
		this.add(this.createButton(shapeType, group));
		
		/* Les ligne qui suivent permettent le chargement dynamique des types de forme d�finis dans les fichiers .class
		du r�pertoire "./plugins" */
		int count = 0; // Compte le nombre d'�l�ments charg�s apr�s le traitement de la m�thode
		try {			
			// R�cup�ration du r�pertoire d'ex�cution du jar
			File dir = new File(ClassLoader.getSystemClassLoader().getResource(".").getPath());
			dir = new File(URLDecoder.decode(dir.getAbsoluteFile() + "/plugins/"));
			
			// Conversion en objet URL
			URL url = dir.toURI().toURL();
			URL[] urls = new URL[]{url};

			// Cr�ation du "chargeur dynamique" via notre url
			ClassLoader classLoader = new URLClassLoader(urls);

			// Parcours des fichiers du r�pertoire
			if((dir.exists()) && (dir.isDirectory())){
				File[] files = dir.listFiles();
				// Si le r�pertoire n'est pas vide
				if((files!=null) && (files.length>0)){			    	
					// Pour chaque �l�ment du r�pertoire
					for(int i=0; i<files.length; i++){
						// Si c'est un fichier .class
						if(files[i].isFile() && files[i].getAbsolutePath().endsWith(".class")){
							// On essaie de la charger dynamiquement en tant qu'objet de la class ShapeType
							shapeType = loadShape(classLoader, "" + files[i].getName().replace(".class", ""));
							// Si le chargement est r�ussi, on l'ajoute au choix du radioBox en lui cr�ant un JRadioButton
							if(shapeType != null){
								shapeTypes.add(shapeType);
								this.add(this.createButton(shapeType, group));
								count++;
							}
						}
					}
				}
			}
		} catch (MalformedURLException e) {
			JOptionPane.showMessageDialog(this, e.getMessage());
			e.printStackTrace();
		}
		catch (Exception e) {
			JOptionPane.showMessageDialog(this, e.getMessage());
			e.printStackTrace();
		}

		// Affichage du nombre d'�l�ments charg�s
		JOptionPane.showMessageDialog(this, count + " formes de dessin charg�es");
	}

	/**
	 * Does the dynamic loading of an ShapeType object from a given class name
	 * @param classLoader a java.lang.ClassLoader object
	 * @param className name of the class with its package path (without the extenxion .class)
	 * @return a ShapeType object or null if an exception occurs
	 * @see ShapeType
	 */
	protected ShapeType loadShape(ClassLoader classLoader, String className){
		try {
			// Chargement dynamiquement d'un objet de la class ShapeType
			ShapeType shape = (ShapeType)  Class.forName(className, true, classLoader).newInstance();		    
			return shape;
		} 
		catch (InstantiationException ex){
			ex.printStackTrace();
		}
		catch (IllegalAccessException ex){
			ex.printStackTrace();
		}
		catch (ClassNotFoundException ex){
			ex.printStackTrace();
		}
		
		// En cas d'exception, aucun objet n'est retourn�
		return null;
	}

	/**
	 * Creates a ShapeTypeRadioButton object to add to the application interface
	 * @param shapeType a ShapeType object
	 * @param group a ButtonGroup object
	 * @return a ShapeTypeRadioButton object
	 */
	protected ShapeTypeRadioButton createButton(ShapeType shapeType, ButtonGroup group){
		ShapeTypeRadioButton radioButton = new ShapeTypeRadioButton(shapeType, group);
		return radioButton;
	}


}
