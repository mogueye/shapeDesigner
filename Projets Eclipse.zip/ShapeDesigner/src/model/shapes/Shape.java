package model.shapes;

import java.awt.Point;
import java.util.Vector;

import view.ShapeType;

/**
 * Class which represent a graphical shape
 * @version 1.0
 * @date Mar. 2017
 * @details It is composed of a set of points. It is also linked to a ShapeType object which defines its kind of graphical shape.
 * @see ShapeType
 */
public class Shape {
	public Vector<Point> points;  /**< list of java.awt.Point */
	protected ShapeType shapeType; /**< the type of the shape as a ShapeType object */
	
	/**
	 * Default constructor
	 */
	public Shape(){
		points = new Vector<Point>();
	}
	
	/**
	 * Surdefined constructor
	 * @param points
	 */
	public Shape(Vector<Point> points){
		this.points = points;
	}
	
	/**
	 * Change the shape by adding inside a border point
	 * @param point a java.awt.Point
	 */
	public void add(Point point){
		this.points.add(point);
	}
	
	
	/**
	 * Change the shape by adding inside a border point
	 * @param x the abscissa of the point
	 * @param y the ordinate of the point
	 */
	public void add(int x, int y){
		this.points.add(new Point(x, y));
	}
	
	/**
	 * Defines the type of the shape
	 * @param shapeType a ShapeType object
	 */
	public void setShapeType(ShapeType shapeType){
		this.shapeType = shapeType;
	}
	
	/**
	 * Returns the type of the shape
	 * @return a ShapeType object
	 */
	public ShapeType getShapeType(){
		return this.shapeType;
	}
}
