package control;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import model.shapes.Shape;

import view.DrawingPanel;
import view.ShapeType;

/**
 * Class which checks the user actions.
 * @version 1.0
 * @date Mar. 2017
 * @details It ensures the supervision of the user actions. It is linked to a DrawingPanel object that it listens user-fires mouse events.
 * @see DrawingPanel
 */
public class UserActionControler implements MouseListener, MouseMotionListener {

	protected DrawingPanel drawingPanel;		/**< its linked DrawingPanel object */
	
	protected boolean dragged = false;	        /**< a boolean attribute to user-dragging actions */
	protected Point draggedFrom;				/**< Starting point of user-dragging action */
	protected Point releasedTo;					/**< Ending point of user-dragging action */
	protected int minimalDistance = 50;	        /**< Minimal accepted distance between the two previous points */
	
	/**
	 * Constructor which needs a value for the minimal accepted distance to draw a shape
	 * @param drawingPanel a DrawingPanel object
	 * @param minimalDistance an integer value
	 */
	public UserActionControler(DrawingPanel drawingPanel, int minimalDistance){
		if(drawingPanel == null)
			throw new NullPointerException("L'objet DrawingPanel ne doit pas �tre nul.");
		
		this.drawingPanel = drawingPanel;
		if(minimalDistance > 0)
			this.minimalDistance = minimalDistance;
	}
	
	/**
	 * Surdefined constructor
	 * @param drawingPanel
	 */
	public UserActionControler(DrawingPanel drawingPanel){
		this(drawingPanel, 50);
	}
	
	/**
	 * Determines if the minimal accepted distance is respected
	 * @param a user starting point
	 * @param b user ending point
	 * @return an integer value
	 */
	protected boolean isAllowedDistance(Point a, Point b){
		int distance = (int)Math.floor(Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2)));
		return distance > this.minimalDistance;
	}
	
	@Override
	public void mouseDragged(MouseEvent mevt) {
		// TODO Auto-generated method stub
		this.dragged = true; // Marquer le d�placement avec la souris enfonc�e
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {}
	
	@Override
	public void mouseClicked(MouseEvent mevt) {}
	
	@Override
	public void mouseEntered(MouseEvent mevt) {}
	
	@Override
	public void mouseExited(MouseEvent mevt) {}

	@Override
	public void mousePressed(MouseEvent mevt) {
		// TODO Auto-generated method stub
		this.draggedFrom = mevt.getPoint(); // M�moriser le point de d�part
	}
	
	@Override
	public void mouseReleased(MouseEvent mevt) {
		// TODO Auto-generated method stub
		if(this.dragged && ShapeType.isSelectedShape()){ // S'il y a du "dragging"
			releasedTo = mevt.getPoint(); // Garder le point d'arriver
			
			if(this.isAllowedDistance(draggedFrom, releasedTo)){ // Si la distance minimale a �t� respect�e
				Shape shape =  new Shape(); // Cr�er une nouvelle forme
				shape.add(draggedFrom); // Ajouter le point de d�part
				shape.add(releasedTo);  // Ajouter le point d'arriver
				shape.setShapeType(ShapeType.getSelectedShape()); // D�finir le type de forme
				
				this.drawingPanel.addShape(shape); // Ajouter la forme au tableau de dessin
			}
		}
		
		// Tout effacer
		draggedFrom  = null;
		releasedTo = null;
		this.dragged = false;
	}
}
